import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import groovy.xml.XmlUtil
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def body = message.getBody();
    message.setBody("");

 
    map = message.getProperties();
    def parser =  new groovy.util.XmlSlurper();
    def inputXml =  parser.parseText(body.replaceAll(/<.xml.*?>/,"") )
       
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("debug CompanyPaymentFileRegisterCollection", body, "text/plain");
       
    message.setProperty("ObjectID", inputXml.CompanyPaymentFileRegisterIncomingFile.ObjectID.text());
    return message;
}
