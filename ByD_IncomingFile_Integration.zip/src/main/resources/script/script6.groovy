
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def body = message.getBody();
        
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("debug CompanyPaymentFileRegisterIncomingFileAttachmentFolder", body, "text/plain");
    return message;
}