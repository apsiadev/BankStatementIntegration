import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body 
    def body =  message.getBody(java.lang.String) as String
    def inputXml = new groovy.util.XmlSlurper().parseText(body);
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def responseLog = "";
    
     inputXml.settlements.each { set ->
        if(set.date_value.text() !=null){
            set.date_value = set.date_value.text().split("T")[0];
        }else{
            set.date_value="";
        }
        
        def cred = getUserCredentials("HiPay").bytes.encodeBase64().toString();
        def url = "https://api.hipay-tpp.com/settlement/"+set.settlementid.text()+"/raw";
        def get = new URL(url).openConnection();
        get.setRequestMethod("GET")
        get.setRequestProperty("Accept", "application/json");
        get.setRequestProperty("Authorization", "Basic " + cred);
        def getRC = get.getResponseCode();
        def jsonResponse = ""
        if(getRC.equals(200)) {
            try {
                jsonResponse = get.getInputStream().getText();
                def jsonParser = new JsonSlurper()
                def json = jsonParser.parseText(jsonResponse)
                def xmlParser = new XmlSlurper(false,false);
                def parentNode = xmlParser.parseText('<items></items>');
                
                def taxes = [:]
                def nodes = []
                def once = true;
                
                json.each{
                    def op_date = it.operation_date;
                    if(op_date!=null){
                        op_date = op_date.split(" ")[0]
                    }else{
                        op_date="";
                    }
                    if(it.operation == "Sale"){
                        def newNode = xmlParser.parseText('<item>'+
                                                        '<settlementid>'+it.settlementid+'</settlementid>'+
                                                        '<trxid>'+it.trxid+'</trxid>'+
                                                        '<account_publicref>'+it.account_publicref+'</account_publicref>'+
                                                        '<date_value>'+it.date_value+'</date_value>'+
                                                        '<amount>'+it.amount+'</amount>'+
                                                        '<tax_amount>'+it.tax_amount+'</tax_amount>'+
                                                        '<net_amount>'+it.net_amount+'</net_amount>'+
                                                        '<operation_date>'+op_date+'</operation_date>'+
                                                    '</item>'); 
                        
                        nodes.add(newNode);
                        
                        
                    }else if(it.operation == "Fixed fee" || it.operation == "Variable" ){
                        if(!taxes.containsKey(""+it.trxid) ){
                            taxes.put(""+it.trxid, 0.0);
                        }
                        
                        taxes.put(""+it.trxid, taxes.get(""+it.trxid)+Float.parseFloat(it.net_amount))
                        responseLog+="debug1 settlement id "+it.trxid+ " taxe : "+taxes[""+it.trxid]+" \n";
                    }
                   
                    if(once){
                        def accnode = xmlParser.parseText('<account_publicref>'+it.account_publicref+'</account_publicref>');
                        set.appendNode(accnode)
                        once = false;
                    }
                    
                }
               
                nodes.each{ node->
                    responseLog+="debug2 settlement id "+node.trxid.text()+ " taxe : "+taxes.get(node.trxid.text())+" \n";
                    def totalTaxe = taxes.get(node.trxid.text());
                    percentTaxe =Math.round(totalTaxe/Float.parseFloat(node.net_amount.text())*100 * 100) / 100 
                    node.tax_amount.replaceBody(Math.abs(percentTaxe));
                    parentNode.appendNode(node);
                }
                set.appendNode(parentNode);
                responseLog+="Success getting raw for settlement id "+set.settlementid.text()+ "\n";
                
            }
            catch(Exception ex) {
                responseLog+="Error getting raw for settlement id "+set.settlementid.text()+", error : "+ex.message+ "\n";
                message.setBody("error");
                return message;
            }
            
        }else{
            responseLog+="Error for settlement id "+set.settlementid.text()+" : code "+getRC + " , url : "+url+ ", message : "+get.getErrorStream().getText()+ "\n";
        }
     
     }
     
     messageLog.addAttachmentAsString("get settlements raw", responseLog, "text/plain");
    message.setBody(groovy.xml.XmlUtil.serialize(inputXml)); 
    return message;
}

def String getUserCredentials(String arg){
    
    def service = ITApiFactory.getApi(SecureStoreService.class, null);   
  
    if( service != null)
    { 
      def credential = service.getUserCredential(arg);
      if (credential == null){
          throw new IllegalStateException("No credential found for alias :" + arg);
      } //String user = credential.getUsername(); String password = new String(credential.getPassword());
      
      return credential.getUsername()+":"+credential.getPassword();
    }
    
	return ""; 
}