import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.camel.impl.DefaultAttachment;
import javax.mail.util.ByteArrayDataSource;
import groovy.xml.XmlUtil
import java.text.SimpleDateFormat

def Message processData(Message message) {
    //Body message as string
    def body =  message.getBody(java.lang.String) as String
    //Get file name prefix from properties
    def map = message.getProperties();
	def prefixName = map.get("FileNamePrefix");
    def extension = map.get("FileExtension");
    
    def parser =  new groovy.util.XmlSlurper();
    //Parse the input xml
    def inputXml =  parser.parseText(body.replaceAll(/<.xml.*?>/,"") )
    //Create the ouput xml root
    def outputXml = parser.parseText("<incomingFile></incomingFile>");
    //For each payment, create a node "File" with a name and a binary string encoded in base 64
    inputXml.PaymentOrderProcessingStatementNotification.eachWithIndex{  it,index->
        def stringContent = XmlUtil.serialize(it).replaceAll(/<.xml.*?>/,"");
        def base64 = stringContent.bytes.encodeBase64().toString();
        def sdf = new SimpleDateFormat("dd-MM-yyyy_HH_mm_ss")
        outputXml.appendNode{
            File{
                Name(prefixName+index+'_'+sdf.format(new Date())+'.'+extension)
                Binary(base64)
            }
        }
        
        
    }
    message.setBody( XmlUtil.serialize(outputXml))
    
    return message;
}