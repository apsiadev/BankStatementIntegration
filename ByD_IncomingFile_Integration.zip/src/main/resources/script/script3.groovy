import org.apache.camel.impl.DefaultAttachment;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.camel.impl.DefaultAttachment;
import javax.mail.util.ByteArrayDataSource;
import groovy.xml.*;

def Message processData(Message message) {
    //Body 
    def messageLog = messageLogFactory.getMessageLog(message);
    def debug = "";
    messageLog.addAttachmentAsString("debug", debug, "text/plain");
    def body =  message.getBody(java.lang.String) as String
    def inputXml = new XmlSlurper().parseText(body)
     
    inputXml.attachments.PaymentOrderProcessingStatementNotification.each{
        def dataSource = new ByteArrayDataSource(it.toString().getBytes('UTF-8'), 'application/xml'); //Set MIME type
        def attachment = new DefaultAttachment(dataSource);
        message.addAttachmentObject("settlement_"+it.ID.text()+".xml", attachment) ;
        debug+=it.ID.text()+"\n";
    }
    
    messageLog.addAttachmentAsString("debug2", debug, "text/plain");
  
    return message;
}